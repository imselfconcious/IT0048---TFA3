<?php

namespace App\Models;

use CodeIgniter\Model;

class CustomerModel extends Model
{
    protected $table = 'customers';
    protected $primaryKey = 'id';
    protected $allowedFields = ['full_name', 'email'];
    protected $returnType = 'array';
    protected $useTimestamps = true;
    public array $validationRules = [
        'full_name' => 'required|min_length[2]|max_length[120]',
        'email' => 'required|valid_email|max_length[160]',
    ];
}

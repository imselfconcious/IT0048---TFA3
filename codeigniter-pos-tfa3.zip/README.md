# CodeIgniter POS TFA3

This standalone CodeIgniter 4 project implements the IT0049 TFA3 requirements: validated customer and user forms, edit and update workflows, unique usernames, avatar upload validation, thumbnail preparation, and placeholder fallback images.

## Requirements

- PHP 8.1 or newer
- Composer
- MySQL or MariaDB
- GD PHP extension for image resizing

## Setup

1. Copy `.env.example` to `.env` and update the database credentials and `app.baseURL`.
2. Create the database and tables by importing `database.sql`.
3. Install dependencies: `composer install`.
4. Ensure `public/uploads/avatars` is writable.
5. Start the app: `php spark serve`.
6. Open `http://localhost:8080`.

The public routes are `/customers`, `/customers/new`, `/users`, `/users/new`, and their edit pages. Uploaded files are validated as JPG or PNG, limited to 2MB, resized to a 300x300 display-ready copy, and only the generated filename is saved in the database.

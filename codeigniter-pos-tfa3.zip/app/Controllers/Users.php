<?php

namespace App\Controllers;

use App\Models\UserModel;

class Users extends BaseController
{
    protected UserModel $users;

    public function __construct()
    {
        $this->users = new UserModel();
    }

    public function index()
    {
        return $this->render('users/index', [
            'title' => 'User Accounts',
            'users' => $this->users->orderBy('id', 'DESC')->findAll(),
        ]);
    }

    public function new()
    {
        return $this->render('users/form', ['title' => 'New User', 'user' => null]);
    }

    public function create()
    {
        if (!$this->validate($this->users->creationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $this->users->insert($this->request->getPost());
        return redirect()->to('/users')->with('message', 'User created successfully.');
    }

    public function edit(int $id)
    {
        $user = $this->users->find($id);
        if (!$user) return redirect()->to('/users')->with('error', 'User not found.');
        return $this->render('users/form', ['title' => 'Edit User', 'user' => $user]);
    }

    public function update(int $id)
    {
        $rules = $this->users->updateRules($id);
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = $this->request->getPost(['username', 'full_name']);
        $file = $this->request->getFile('avatar');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $filename = $file->getRandomName();
            $file->move(FCPATH . 'uploads/avatars', $filename);
            service('image')->withFile(FCPATH . 'uploads/avatars/' . $filename)
                ->fit(300, 300, 'center')->save(FCPATH . 'uploads/avatars/thumb_' . $filename);
            $data['avatar'] = 'thumb_' . $filename;
        }
        $this->users->update($id, $data);
        return redirect()->to('/users')->with('message', 'User updated successfully.');
    }
}

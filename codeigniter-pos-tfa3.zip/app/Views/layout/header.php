<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= esc($title ?? 'POS') ?></title>
    <style>
      body{font-family:Arial,sans-serif;background:#f4f6f8;color:#1f2937;margin:0}nav{background:#172554;padding:16px 8%;display:flex;gap:24px}nav a{color:#fff;text-decoration:none;font-weight:700}.wrap{max-width:1000px;margin:36px auto;padding:0 20px}h1{margin-bottom:24px}.card{background:#fff;padding:24px;border-radius:12px;box-shadow:0 2px 10px #0001;margin-bottom:20px}table{width:100%;border-collapse:collapse;background:#fff}th,td{padding:13px;border-bottom:1px solid #e5e7eb;text-align:left}th{background:#e0e7ff}.btn{display:inline-block;background:#2563eb;color:#fff;padding:10px 14px;border-radius:7px;text-decoration:none;border:0;cursor:pointer}.btn.secondary{background:#475569}label{display:block;font-weight:700;margin-top:15px}input{width:100%;box-sizing:border-box;padding:10px;margin-top:6px;border:1px solid #cbd5e1;border-radius:6px}.error{color:#b91c1c;font-size:.9rem}.flash{padding:12px;background:#dcfce7;color:#166534;border-radius:6px;margin-bottom:15px}.avatar{width:48px;height:48px;border-radius:50%;object-fit:cover;vertical-align:middle}
    </style>
</head><body><nav><a href="/">POS Dashboard</a><a href="/customers">Customers</a><a href="/users">Users</a></nav><main class="wrap">
<?php if (session()->getFlashdata('message')): ?><div class="flash"><?= esc(session()->getFlashdata('message')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="error"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<?php

namespace App\Controllers;

use App\Models\CustomerModel;

class Customers extends BaseController
{
    protected CustomerModel $customers;

    public function __construct()
    {
        $this->customers = new CustomerModel();
    }

    public function index()
    {
        return $this->render('customers/index', [
            'title' => 'Customer Accounts',
            'customers' => $this->customers->orderBy('id', 'DESC')->findAll(),
        ]);
    }

    public function new()
    {
        return $this->render('customers/form', ['title' => 'New Customer', 'customer' => null]);
    }

    public function create()
    {
        if (!$this->validate($this->customers->validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $this->customers->insert($this->request->getPost());
        return redirect()->to('/customers')->with('message', 'Customer created successfully.');
    }

    public function edit(int $id)
    {
        $customer = $this->customers->find($id);
        if (!$customer) return redirect()->to('/customers')->with('error', 'Customer not found.');
        return $this->render('customers/form', ['title' => 'Edit Customer', 'customer' => $customer]);
    }

    public function update(int $id)
    {
        if (!$this->validate($this->customers->validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $this->customers->update($id, $this->request->getPost());
        return redirect()->to('/customers')->with('message', 'Customer updated successfully.');
    }
}

<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $allowedFields = ['username', 'full_name', 'avatar'];
    protected $returnType = 'array';
    protected $useTimestamps = true;
    public array $creationRules = [
        'username' => 'required|alpha_numeric_punct|min_length[3]|max_length[60]|is_unique[users.username]',
        'full_name' => 'required|min_length[2]|max_length[120]',
    ];
    public function updateRules(int $id): array
    {
        return [
            'username' => "required|alpha_numeric_punct|min_length[3]|max_length[60]|is_unique[users.username,id,{$id}]",
            'full_name' => 'required|min_length[2]|max_length[120]',
            'avatar' => 'permit_empty|is_image[avatar]|mime_in[avatar,image/jpg,image/jpeg,image/png]|max_size[avatar,2048]',
        ];
    }
}

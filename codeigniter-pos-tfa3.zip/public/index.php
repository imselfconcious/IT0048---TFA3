<?php

use CodeIgniter\Boot;
use Config\Paths;

require FCPATH . '../app/Config/Paths.php';
$paths = new Paths();
require rtrim($paths->systemDirectory, '\\/ ') . DIRECTORY_SEPARATOR . 'Boot.php';
exit(Boot::bootWeb($paths));

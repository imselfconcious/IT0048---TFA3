<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
    public function index()
    {
        return $this->render('dashboard', ['title' => 'POS Dashboard']);
    }
}
